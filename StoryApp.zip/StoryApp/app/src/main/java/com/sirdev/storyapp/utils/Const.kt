package com.sirdev.storyapp.utils

class Const {
    companion object {
        const val NAME_KEY = "NAME"
        const val TOKEN_KEY = "TOKEN"
        const val USER_ID_KEY = "USER_ID"
        const val STATE_KEY = "STATE"
    }
}